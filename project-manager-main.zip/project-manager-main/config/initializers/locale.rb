I18n.available_locales = [:en, :'pt-BR']
I18n.default_locale = :'pt-BR'