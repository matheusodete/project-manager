# project-manager
A web-based system for managing and evaluating scientific initiation projects. Features a smooth layout, efficient forms, and customization options.